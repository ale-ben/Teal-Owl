## Google Doc to clean HTML converter ##

 1. Open your Google Doc and go to Tools menu, select Script Editor. You
    should see a new window open with a nice code editor. 
 2. Copy and paste the code from here: [GoogleDocs2Html][1]
 3. Go to the File menu and Save the file the script as GoogleDoc2Html.
 4. Then from the Run menu, choose ConvertGoogleDocToCleanHtml
 5. A popup window will appear titled, Authorization required.  
    Click continue to grant the following permissions:
    Know who you are on Google
    View your email address
    View and manage your documents in Google Drive
    Send email as you
 6. You will get an email at your Google Account containing the HTML
    output of the Google Doc with inline images.

  [1]: https://raw.githubusercontent.com/thejimbirch/GoogleDoc2Html/master/code.js
